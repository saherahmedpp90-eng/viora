VIORA - رفع الصفحة على GitHub Pages

1. ادخل على github.com وسوّي حساب (لو ما عندك).
2. اضغط New repository وسمّيه مثلًا viora، واختار Public، وبعدين Create repository.
3. اضغط "uploading an existing file" وارفع الملفات دي مع بعض:
   - index.html
   - فولدر img (فيه الصور الأربعة)
   مهم: لازم يكون الملف اسمه index.html بالظبط وفولدر الصور اسمه img.
4. اضغط Commit changes.
5. من Settings > Pages: في Source اختار "Deploy from a branch"، وفي Branch اختار main و / (root)، واضغط Save.
6. بعد دقيقة أو دقيقتين الرابط يظهر في نفس الصفحة بالشكل: https://اسم-حسابك.github.io/viora/

بيكسل TikTok (DBR24G3C77U0LPHEN5S0) موجود في هيدر index.html.
الأحداث اللي بتتسجل:
- Page view: عند فتح الصفحة
- AddToCart: أول ما العميلة تضيف أي مشروب في الحاسبة
- InitiateCheckout: لما تضغط "راجعي الحجز" والبيانات كاملة (مع قيمة الطلب بالدينار الكويتي)
- Contact و SubmitForm: لما تضغط "تأكيد وإرسال عبر واتساب"
- Contact: لما تضغط زر واتساب في آخر الصفحة

للتأكد إن البيكسل شغال: افتح الصفحة بعد الرفع وانت مثبّت إضافة TikTok Pixel Helper على Chrome.
